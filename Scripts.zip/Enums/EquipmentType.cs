public enum EquipmentType
{
    Weapon,
    Top,
    Bottom
}

public enum WeaponType
{
    Sword,
    Bow
}