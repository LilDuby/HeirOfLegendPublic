public enum EffectType
{
    HealOverTime = 0,
    StatBoost,
    ImmediateHeal
}
