public enum ConsumableType
{
    Potion,
    Food,
    Scroll
}
