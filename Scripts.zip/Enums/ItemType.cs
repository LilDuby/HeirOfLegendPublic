public enum ItemType
{    
    Equipment_Weapon_Sword,
    Equipment_Weapon_Bow,
    Equipment_Armer_Top,
    Equipment_Armer_Bottom,
    Consumable_CanUse,
    Consumable_NoUse
}
