

public class KeyGuidePopup : PopupUI
{
    public void OnClickBack()
    { 
        UIManager.instance.HideUI<KeyGuidePopup>();
    }
}
